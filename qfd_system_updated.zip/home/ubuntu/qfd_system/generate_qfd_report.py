
import json
import os
from fpdf import FPDF, XPos, YPos

class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Relatório Técnico QFD", 0, 1, "C")
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Página {self.page_no()}/{{nb}}", 0, 0, "C")

    def chapter_title(self, title):
        self.set_font("Arial", "B", 12)
        self.set_fill_color(230, 230, 230)
        self.cell(0, 10, title, new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="L", fill=True)
        self.ln(5)

    def chapter_body(self, body):
        self.set_font("Arial", "", 10)
        self.multi_cell(0, 5, body)
        self.ln()

    def add_requirements_dictionary(self, req_cliente, req_projeto):
        self.chapter_title("Dicionário de Requisitos")
        self.set_font("Arial", "B", 10)
        self.cell(0, 7, "Requisitos do Cliente (RC)", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="L")
        self.set_font("Arial", "", 9)
        for i, req in enumerate(req_cliente):
            self.cell(0, 6, f"RC{i+1} ({req["id"]}) : {req["descricao"]}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="L")
        self.ln(5)

        self.set_font("Arial", "B", 10)
        self.cell(0, 7, "Requisitos de Projeto (RP)", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="L")
        self.set_font("Arial", "", 9)
        for i, req in enumerate(req_projeto):
            self.cell(0, 6, f"RP{i+1} ({req["id"]}) : {req["descricao"]}", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="L")
        self.ln(10)

    def add_qfd_matrix(self, data):
        self.add_page("L") # Landscape
        self.set_font("Arial", "B", 10)
        self.chapter_title("Matriz QFD (Casa da Qualidade)")

        req_cliente = data["requisitosCliente"]
        req_projeto = data["requisitosProjeto"]
        correlacoes = data["correlacoesProjeto"]
        matriz_qfd = data["matrizQFD"]

        # Calculate column widths
        col_width_cliente = 60
        col_width_projeto = 15 # Each project requirement column
        col_width_importancia = 20

        # Store current Y position for vertical text alignment
        start_y = self.get_y()

        # Header Row 1: Project Requirements (vertical text)
        self.set_fill_color(102, 126, 234) # Purple-blue
        self.set_text_color(255, 255, 255)
        self.set_font("Arial", "B", 8)

        # Empty corner cell
        self.cell(col_width_cliente, 40, "", 1, 0, "C", 1)

        # Project requirements vertical headers
        for i, req_p in enumerate(req_projeto):
            # Save current position
            x_pos = self.get_x()
            y_pos = self.get_y()

            # Rotate and write text
            self.rotate(90, x_pos + col_width_projeto / 2, y_pos + 40 / 2)
            self.text(x_pos + col_width_projeto / 2, y_pos + 40 / 2, f"Req P{i+1}: {req_p["descricao"]}")
            self.rotate(0) # Reset rotation

            # Draw cell border and move to next position
            self.rect(x_pos, y_pos, col_width_projeto, 40)
            self.set_xy(x_pos + col_width_projeto, y_pos)

        self.cell(col_width_importancia, 40, "Importância Cliente", 1, 1, "C", 1)

        # QFD Roof (Correlations)
        self.set_fill_color(248, 249, 250) # Light gray
        self.set_text_color(0, 0, 0)
        self.set_font("Arial", "", 8)

        for i in range(len(req_projeto) - 1):
            self.cell(col_width_cliente, 10, "", 1, 0, "C", 1) # Empty cell for client reqs
            
            # Empty cells for the lower triangle
            for _ in range(i + 1):
                self.cell(col_width_projeto, 10, "", 1, 0, "C", 1)
            
            # Correlation cells
            for j in range(i + 1, len(req_projeto)):
                corr_val = "0"
                for corr in correlacoes:
                    if (corr["requisito1"] == req_projeto[i]["id"] and corr["requisito2"] == req_projeto[j]["id"]) or \
                       (corr["requisito1"] == req_projeto[j]["id"] and corr["requisito2"] == req_projeto[i]["id"]):
                        corr_val = corr["correlacao"]
                        break
                self.cell(col_width_projeto, 10, corr_val, 1, 0, "C", 1)
            self.cell(col_width_importancia, 10, "", 1, 1, "C", 1) # Empty cell for importance

        # Matrix Body
        self.set_font("Arial", "", 8)
        for i, req_c in enumerate(req_cliente):
            self.set_fill_color(248, 249, 250)
            self.set_text_color(0, 0, 0)
            self.cell(col_width_cliente, 10, f"Req C{i+1}: {req_c["descricao"]}", 1, 0, "L", 1)

            for j, req_p in enumerate(req_projeto):
                influence_val = 0
                for infl in matriz_qfd:
                    if infl["requisitoCliente"] == req_c["id"] and infl["requisitoProjeto"] == req_p["id"]:
                        influence_val = infl["influencia"]
                        break
                self.cell(col_width_projeto, 10, str(influence_val), 1, 0, "C")
            
            self.set_fill_color(255, 243, 205) # Light yellow
            self.set_text_color(133, 100, 4)
            self.cell(col_width_importancia, 10, f"{req_c["importancia"]:.1f}", 1, 1, "C", 1)

        # Footer Rows (Importance, Ranking, Relative Weight, Technical Difficulty)
        self.set_fill_color(233, 236, 239) # Lighter gray
        self.set_text_color(0, 0, 0)
        self.set_font("Arial", "B", 8)

        footer_labels = [
            "Importância Absoluta",
            "Ranking",
            "Peso Relativo (%)",
            "Dificuldade Técnica"
        ]

        footer_data_keys = [
            "importanciaAbsoluta",
            "importanciaRelativa",
            "pesoRelativo",
            "dificuldadeTecnica"
        ]

        for k, label in enumerate(footer_labels):
            self.cell(col_width_cliente, 10, label, 1, 0, "L", 1)
            for req_p in req_projeto:
                val = req_p[footer_data_keys[k]]
                if footer_data_keys[k] == "pesoRelativo":
                    val = f"{val * 100:.1f}"
                elif footer_data_keys[k] == "importanciaRelativa":
                    val = f"{val}º"
                else:
                    val = f"{val:.1f}"
                self.cell(col_width_projeto, 10, str(val), 1, 0, "C", 1)
            self.cell(col_width_importancia, 10, "", 1, 1, "C", 1)

# Load data from database.js (simulated)
# In a real scenario, you'd parse the localStorage data or fetch from a backend
def load_qfd_data(db_path):
    # This is a simplified way to get data from the JS file
    # In a more robust solution, you'd need a proper JS parser or a backend API
    with open(db_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Extract data using regex or string manipulation (very fragile)
    # For a real system, expose data via a proper API or JSON file
    
    # Dummy data for now, as parsing JS is complex
    # You would replace this with actual data extraction from localStorage or a backend
    return {
        "requisitosCliente": [
            {"id": "rc1", "descricao": "O produto deve ser fácil de usar", "importancia": 5, "peso": 0.25},
            {"id": "rc2", "descricao": "O produto deve ser durável", "importancia": 4, "peso": 0.20},
            {"id": "rc3", "descricao": "O produto deve ter um design moderno", "importancia": 3, "peso": 0.15},
            {"id": "rc4", "descricao": "O produto deve ser econômico", "importancia": 5, "peso": 0.25},
            {"id": "rc5", "descricao": "O produto deve ser seguro", "importancia": 3, "peso": 0.15}
        ],
        "requisitosProjeto": [
            {"id": "rp1", "descricao": "Interface intuitiva", "sentidoMelhoria": "up", "dificuldadeTecnica": 1, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0},
            {"id": "rp2", "descricao": "Materiais de alta resistência", "sentidoMelhoria": "up", "dificuldadeTecnica": 2, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0},
            {"id": "rp3", "descricao": "Acabamento premium", "sentidoMelhoria": "up", "dificuldadeTecnica": 3, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0},
            {"id": "rp4", "descricao": "Consumo de energia otimizado", "sentidoMelhoria": "down", "dificuldadeTecnica": 2, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0}
        ],
        "correlacoesProjeto": [
            {"requisito1": "rp1", "requisito2": "rp2", "correlacao": "0"},
            {"requisito1": "rp1", "requisito2": "rp3", "correlacao": "+"},
            {"requisito1": "rp1", "requisito2": "rp4", "correlacao": "-"},
            {"requisito1": "rp2", "requisito2": "rp3", "correlacao": "++"},
            {"requisito1": "rp2", "requisito2": "rp4", "correlacao": "0"},
            {"requisito1": "rp3", "requisito2": "rp4", "correlacao": "-"}
        ],
        "matrizQFD": [
            {"requisitoCliente": "rc1", "requisitoProjeto": "rp1", "influencia": 5},
            {"requisitoCliente": "rc1", "requisitoProjeto": "rp2", "influencia": 1},
            {"requisitoCliente": "rc1", "requisitoProjeto": "rp3", "influencia": 3},
            {"requisitoCliente": "rc1", "requisitoProjeto": "rp4", "influencia": 1},

            {"requisitoCliente": "rc2", "requisitoProjeto": "rp1", "influencia": 1},
            {"requisitoCliente": "rc2", "requisitoProjeto": "rp2", "influencia": 5},
            {"requisitoCliente": "rc2", "requisitoProjeto": "rp3", "influencia": 3},
            {"requisitoCliente": "rc2", "requisitoProjeto": "rp4", "influencia": 1},

            {"requisitoCliente": "rc3", "requisitoProjeto": "rp1", "influencia": 3},
            {"requisitoCliente": "rc3", "requisitoProjeto": "rp2", "influencia": 1},
            {"requisitoCliente": "rc3", "requisitoProjeto": "rp3", "influencia": 5},
            {"requisitoCliente": "rc3", "requisitoProjeto": "rp4", "influencia": 1},

            {"requisitoCliente": "rc4", "requisitoProjeto": "rp1", "influencia": 1},
            {"requisitoCliente": "rc4", "requisitoProjeto": "rp2", "influencia": 1},
            {"requisitoCliente": "rc4", "requisitoProjeto": "rp3", "influencia": 1},
            {"requisitoCliente": "rc4", "requisitoProjeto": "rp4", "influencia": 5},

            {"requisitoCliente": "rc5", "requisitoProjeto": "rp1", "influencia": 3},
            {"requisitoCliente": "rc5", "requisitoProjeto": "rp2", "influencia": 3},
            {"requisitoCliente": "rc5", "requisitoProjeto": "rp3", "influencia": 1},
            {"requisitoCliente": "rc5", "requisitoProjeto": "rp4", "influencia": 3}
        ]
    }

def calculate_qfd_metrics(data):
    req_cliente = data["requisitosCliente"]
    req_projeto = data["requisitosProjeto"]
    matriz_qfd = data["matrizQFD"]

    # Calculate Absolute Importance for Project Requirements
    for rp in req_projeto:
        abs_importance = 0
        for rc in req_cliente:
            influence = 0
            for infl in matriz_qfd:
                if infl["requisitoCliente"] == rc["id"] and infl["requisitoProjeto"] == rp["id"]:
                    influence = infl["influencia"]
                    break
            abs_importance += rc["importancia"] * influence
        rp["importanciaAbsoluta"] = abs_importance

    # Calculate Ranking and Relative Weight
    sorted_rp = sorted(req_projeto, key=lambda x: x["importanciaAbsoluta"], reverse=True)
    total_abs_importance = sum(rp["importanciaAbsoluta"] for rp in req_projeto)

    for i, rp in enumerate(sorted_rp):
        rp["importanciaRelativa"] = i + 1
        rp["pesoRelativo"] = rp["importanciaAbsoluta"] / total_abs_importance if total_    # In a real scenario, you'd parse the localStorage data or fetch from a backend
    # For now, we'll assume the data is passed directly or loaded from a file
    # This function will be called with the actual data from the JS side.
    return data


if __name__ == "__main__":
    # This part would typically be run from a server-side component
    # that receives the QFD data from the frontend.
    # For demonstration, we'll load a dummy data structure.
    
    # Example of how to get data from the browser's localStorage:
    # 1. Open the QFD system in your browser.
    # 2. Open the browser's developer console (F12).
    # 3. Run: `copy(localStorage.getItem('qfd_data'))`
    # 4. Paste the copied content into a file named `qfd_data.json` in the same directory as this script.
    # 5. Uncomment the lines below to load from the file.

    # Load data from a JSON file (simulating data from localStorage)
    try:
        with open("/home/ubuntu/qfd_system/qfd_data.json", "r", encoding="utf-8") as f:
            qfd_data = json.load(f)
    except FileNotFoundError:
        print("Erro: qfd_data.json não encontrado. Por favor, exporte os dados do navegador ou crie um arquivo com dados de exemplo.")
        # Fallback to dummy data if file not found
        qfd_data = {
            "requisitosCliente": [
                {"id": "rc1", "descricao": "O produto deve ser fácil de usar", "importancia": 5, "peso": 0.25},
                {"id": "rc2", "descricao": "O produto deve ser durável", "importancia": 4, "peso": 0.20},
                {"id": "rc3", "descricao": "O produto deve ter um design moderno", "importancia": 3, "peso": 0.15},
                {"id": "rc4", "descricao": "O produto deve ser econômico", "importancia": 5, "peso": 0.25},
                {"id": "rc5", "descricao": "O produto deve ser seguro", "importancia": 3, "peso": 0.15}
            ],
            "requisitosProjeto": [
                {"id": "rp1", "descricao": "Interface intuitiva", "sentidoMelhoria": "up", "dificuldadeTecnica": 1, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0},
                {"id": "rp2", "descricao": "Materiais de alta resistência", "sentidoMelhoria": "up", "dificuldadeTecnica": 2, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0},
                {"id": "rp3", "descricao": "Acabamento premium", "sentidoMelhoria": "up", "dificuldadeTecnica": 3, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0},
                {"id": "rp4", "descricao": "Consumo de energia otimizado", "sentidoMelhoria": "down", "dificuldadeTecnica": 2, "importanciaAbsoluta": 0, "importanciaRelativa": 0, "pesoRelativo": 0}
            ],
            "correlacoesProjeto": [
                {"requisito1": "rp1", "requisito2": "rp2", "correlacao": "0"},
                {"requisito1": "rp1", "requisito2": "rp3", "correlacao": "+"},
                {"requisito1": "rp1", "requisito2": "rp4", "correlacao": "-"},
                {"requisito1": "rp2", "requisito2": "rp3", "correlacao": "++"},
                {"requisito1": "rp2", "requisito2": "rp4", "correlacao": "0"},
                {"requisito1": "rp3", "requisito2": "rp4", "correlacao": "-"}
            ],
            "matrizQFD": [
                {"requisitoCliente": "rc1", "requisitoProjeto": "rp1", "influencia": 5},
                {"requisitoCliente": "rc1", "requisitoProjeto": "rp2", "influencia": 1},
                {"requisitoCliente": "rc1", "requisitoProjeto": "rp3", "influencia": 3},
                {"requisitoCliente": "rc1", "requisitoProjeto": "rp4", "influencia": 1},

                {"requisitoCliente": "rc2", "requisitoProjeto": "rp1", "influencia": 1},
                {"requisitoCliente": "rc2", "requisitoProjeto": "rp2", "influencia": 5},
                {"requisitoCliente": "rc2", "requisitoProjeto": "rp3", "influencia": 3},
                {"requisitoCliente": "rc2", "requisitoProjeto": "rp4", "influencia": 1},

                {"requisitoCliente": "rc3", "requisitoProjeto": "rp1", "influencia": 3},
                {"requisitoCliente": "rc3", "requisitoProjeto": "rp2", "influencia": 1},
                {"requisitoCliente": "rc3", "requisitoProjeto": "rp3", "influencia": 5},
                {"requisitoCliente": "rc3", "requisitoProjeto": "rp4", "influencia": 1},

                {"requisitoCliente": "rc4", "requisitoProjeto": "rp1", "influencia": 1},
                {"requisitoCliente": "rc4", "requisitoProjeto": "rp2", "influencia": 1},
                {"requisitoCliente": "rc4", "requisitoProjeto": "rp3", "influencia": 1},
                {"requisitoCliente": "rc4", "requisitoProjeto": "rp4", "influencia": 5},

                {"requisitoCliente": "rc5", "requisitoProjeto": "rp1", "influencia": 3},
                {"requisitoCliente": "rc5", "requisitoProjeto": "rp2", "influencia": 3},
                {"requisitoCliente": "rc5", "requisitoProjeto": "rp3", "influencia": 1},
                {"requisitoCliente": "rc5", "requisitoProjeto": "rp4", "influencia": 3}
            ]
        }

    output_pdf_path = "/home/ubuntu/qfd_system/relatorio_qfd_padronizado.pdf"

    qfd_data = calculate_qfd_metrics(qfd_data)

    pdf = PDF()
    pdf.alias_nb_pages()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)

    pdf.chapter_title("Introdução")
    pdf.chapter_body("Este relatório apresenta a Matriz QFD (Quality Function Deployment) para o projeto, detalhando a relação entre os requisitos do cliente e os requisitos de projeto. A Matriz QFD, também conhecida como Casa da Qualidade, é uma ferramenta essencial para traduzir as necessidades dos clientes em características técnicas do produto ou serviço.")

    pdf.add_requirements_dictionary(qfd_data["requisitosCliente"], qfd_data["requisitosProjeto"])

    pdf.add_qfd_matrix(qfd_data)

    pdf.output(output_pdf_path)
    print(f"Relatório QFD gerado em: {output_pdf_path}")