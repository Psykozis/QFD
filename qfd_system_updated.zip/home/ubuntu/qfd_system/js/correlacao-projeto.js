/**
 * JavaScript para Página de Correlação de Requisitos de Projeto
 * Implementa o telhado da casa QFD com pop-ups instantâneos
 */

let requisitos = [];
let totalCorrelacoes = 0;
let correlacoesFeitas = 0;

document.addEventListener('DOMContentLoaded', function() {
    loadRequisitos();
    setupCorrelation();
    updateStatus();
    addModalStyles();
});

function loadRequisitos() {
    requisitos = qfdDB.getRequisitosProjeto();
    totalCorrelacoes = calculateTotalCorrelations(requisitos.length);
    
    const correlacoes = qfdDB.getCorrelacoesProjeto();
    correlacoesFeitas = correlacoes.length;
}

function calculateTotalCorrelations(count) {
    return count > 1 ? (count * (count - 1)) / 2 : 0;
}

function setupCorrelation() {
    const insufficientDiv = document.getElementById('insufficient-requirements');
    const correlationSection = document.getElementById('correlation-section');
    const legendSection = document.getElementById('correlation-legend');
    const analysisSection = document.getElementById('analysis-section');
    
    if (requisitos.length < 2) {
        insufficientDiv.style.display = 'block';
        correlationSection.style.display = 'none';
        legendSection.style.display = 'none';
        analysisSection.style.display = 'none';
        return;
    }
    
    insufficientDiv.style.display = 'none';
    correlationSection.style.display = 'block';
    legendSection.style.display = 'block';
    
    generateRoofMatrix();
    
    if (correlacoesFeitas > 0) {
        showAnalysis();
    }
}

function generateRoofMatrix() {
    const roofContainer = document.getElementById('roof-matrix');
    if (!roofContainer) return;
    
    let roofHTML = '<div class="roof-table">';
    
    // Cabeçalho com números dos requisitos (começando da segunda coluna)
    roofHTML += '<div class="roof-header">';
    for (let i = 1; i < requisitos.length; i++) {
        roofHTML += `<div class="roof-header-cell" title="${escapeHtml(requisitos[i].descricao)}">
            <span class="req-number">${i + 1}</span>
        </div>`;
    }
    roofHTML += '</div>';
    
    // Matriz triangular retângulo
    for (let i = 0; i < requisitos.length - 1; i++) {
        roofHTML += '<div class="roof-row">';
        
        // Cabeçalho da linha (requisito atual)
        roofHTML += `<div class="roof-row-header" title="${escapeHtml(requisitos[i].descricao)}">
            <span class="req-number">${i + 1}</span>
        </div>`;
        
        // Células de correlação (comparando com os requisitos seguintes)
        for (let j = i + 1; j < requisitos.length; j++) {
            const correlation = qfdDB.getCorrelacaoProjeto(requisitos[i].id, requisitos[j].id);
            const isCompleted = correlation !== '0';
            
            roofHTML += `<div class="roof-cell ${isCompleted ? 'completed' : ''}" 
                onclick="openCorrelationPopup('${requisitos[i].id}', '${requisitos[j].id}', ${i}, ${j})"
                data-req1="${requisitos[i].id}" 
                data-req2="${requisitos[j].id}"
                data-i="${i}" 
                data-j="${j}">
                ${getCorrelationDisplay(correlation)}
            </div>`;
        }
        
        roofHTML += '</div>';
    }
    
    roofHTML += '</div>';
    
    // Legenda dos requisitos
    roofHTML += '<div class="roof-legend">';
    roofHTML += '<h4>Requisitos de Projeto:</h4>';
    roofHTML += '<div class="legend-items">';
    
    for (let i = 0; i < requisitos.length; i++) {
        const req = requisitos[i];
        roofHTML += `<div class="legend-item">
            <span class="legend-number">${i + 1}</span>
            <div class="legend-content">
                <span class="legend-text">${escapeHtml(req.descricao)}</span>
                <div class="legend-meta">
                    <span class="sentido-badge ${req.sentidoMelhoria}">
                        ${getSentidoSymbol(req.sentidoMelhoria)} ${getSentidoLabel(req.sentidoMelhoria)}
                    </span>
                    <span class="dificuldade-badge level-${req.dificuldadeTecnica}">
                        Dif: ${req.dificuldadeTecnica}
                    </span>
                </div>
            </div>
        </div>`;
    }
    
    roofHTML += '</div></div>';
    
    roofContainer.innerHTML = roofHTML;
}

function getSentidoSymbol(sentido) {
    const symbols = { 'up': '↑', 'down': '↓', 'none': '*' };
    return symbols[sentido] || '?';
}

function getSentidoLabel(sentido) {
    const labels = { 'up': 'Crescente', 'down': 'Decrescente', 'none': 'Nominal' };
    return labels[sentido] || 'Indefinido';
}

function getCorrelationDisplay(correlation) {
    const symbols = {
        '++': '<span class="corr-symbol strong-positive">++</span>',
        '+': '<span class="corr-symbol positive">+</span>',
        '0': '<span class="corr-symbol neutral">0</span>',
        '-': '<span class="corr-symbol negative">-</span>',
        '--': '<span class="corr-symbol strong-negative">--</span>'
    };
    
    return symbols[correlation] || '<span class="corr-placeholder">?</span>';
}

function openCorrelationPopup(req1Id, req2Id, i, j) {
    const req1 = requisitos[i];
    const req2 = requisitos[j];
    const currentCorrelation = qfdDB.getCorrelacaoProjeto(req1Id, req2Id);
    
    // Remove qualquer modal existente
    const existingModal = document.querySelector('.correlation-popup');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Cria popup
    const popup = document.createElement('div');
    popup.className = 'correlation-popup';
    popup.innerHTML = `
        <div class="popup-overlay" onclick="closeCorrelationPopup()"></div>
        <div class="popup-content">
            <div class="popup-header">
                <h3>Correlação entre Requisitos</h3>
                <button class="popup-close" onclick="closeCorrelationPopup()">&times;</button>
            </div>
            <div class="popup-body">
                <div class="requirements-comparison">
                    <div class="req-display">
                        <div class="req-number">${i + 1}</div>
                        <div class="req-text">${escapeHtml(req1.descricao)}</div>
                        <div class="req-meta">
                            ${getSentidoSymbol(req1.sentidoMelhoria)} ${getSentidoLabel(req1.sentidoMelhoria)} | Dif: ${req1.dificuldadeTecnica}
                        </div>
                    </div>
                    <div class="vs-separator">vs</div>
                    <div class="req-display">
                        <div class="req-number">${j + 1}</div>
                        <div class="req-text">${escapeHtml(req2.descricao)}</div>
                        <div class="req-meta">
                            ${getSentidoSymbol(req2.sentidoMelhoria)} ${getSentidoLabel(req2.sentidoMelhoria)} | Dif: ${req2.dificuldadeTecnica}
                        </div>
                    </div>
                </div>
                
                <div class="correlation-question">
                    <h4>Como estes requisitos se relacionam?</h4>
                </div>
                
                <div class="correlation-options">
                    <button class="corr-option ${currentCorrelation === '++' ? 'selected' : ''}" 
                            onclick="selectCorrelation('++', '${req1Id}', '${req2Id}')">
                        <span class="corr-symbol strong-positive">++</span>
                        <span class="corr-label">Muito Positiva</span>
                        <small>Se reforçam significativamente</small>
                    </button>
                    <button class="corr-option ${currentCorrelation === '+' ? 'selected' : ''}" 
                            onclick="selectCorrelation('+', '${req1Id}', '${req2Id}')">
                        <span class="corr-symbol positive">+</span>
                        <span class="corr-label">Positiva</span>
                        <small>Se complementam</small>
                    </button>
                    <button class="corr-option ${currentCorrelation === '0' ? 'selected' : ''}" 
                            onclick="selectCorrelation('0', '${req1Id}', '${req2Id}')">
                        <span class="corr-symbol neutral">0</span>
                        <span class="corr-label">Neutra</span>
                        <small>São independentes</small>
                    </button>
                    <button class="corr-option ${currentCorrelation === '-' ? 'selected' : ''}" 
                            onclick="selectCorrelation('-', '${req1Id}', '${req2Id}')">
                        <span class="corr-symbol negative">-</span>
                        <span class="corr-label">Negativa</span>
                        <small>Competem entre si</small>
                    </button>
                    <button class="corr-option ${currentCorrelation === '--' ? 'selected' : ''}" 
                            onclick="selectCorrelation('--', '${req1Id}', '${req2Id}')">
                        <span class="corr-symbol strong-negative">--</span>
                        <span class="corr-label">Muito Negativa</span>
                        <small>São conflitantes</small>
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(popup);
    
    // Anima a entrada
    setTimeout(() => {
        popup.classList.add('show');
    }, 10);
}

function selectCorrelation(correlation, req1Id, req2Id) {
    try {
        // Salva imediatamente
        qfdDB.setCorrelacaoProjeto(req1Id, req2Id, correlation);
        
        // Atualiza interface
        loadRequisitos();
        generateRoofMatrix();
        updateStatus();
        showAnalysis();
        
        // Fecha popup
        closeCorrelationPopup();
        
        // Mostra feedback
        showToast('Correlação salva com sucesso!', 'success');
        
    } catch (error) {
        console.error('Erro ao salvar correlação:', error);
        showToast('Erro ao salvar correlação', 'error');
    }
}

function closeCorrelationPopup() {
    const popup = document.querySelector('.correlation-popup');
    if (popup) {
        popup.classList.add('hide');
        setTimeout(() => {
            popup.remove();
        }, 300);
    }
}

function updateStatus() {
    const totalReqElement = document.getElementById('total-requisitos');
    const correlacoesElement = document.getElementById('correlacoes-feitas');
    const progressoElement = document.getElementById('progresso-percentual');
    const progressFill = document.getElementById('progress-fill');
    
    if (totalReqElement) {
        totalReqElement.textContent = `${requisitos.length} Requisitos`;
    }
    
    if (correlacoesElement) {
        correlacoesElement.textContent = `${correlacoesFeitas} / ${totalCorrelacoes}`;
    }
    
    const progresso = totalCorrelacoes > 0 ? Math.round((correlacoesFeitas / totalCorrelacoes) * 100) : 0;
    
    if (progressoElement) {
        progressoElement.textContent = `${progresso}%`;
    }
    
    if (progressFill) {
        progressFill.style.width = `${progresso}%`;
    }
}

function showAnalysis() {
    const analysisSection = document.getElementById('analysis-section');
    if (!analysisSection) return;
    
    analysisSection.style.display = 'block';
    
    generateCorrelationSummary();
    generateConflictAnalysis();
    generateSynergyAnalysis();
}

function generateCorrelationSummary() {
    const summaryContainer = document.getElementById('correlation-summary');
    if (!summaryContainer) return;
    
    const correlacoes = qfdDB.getCorrelacoesProjeto();
    
    // Conta tipos de correlação
    const counts = {
        '++': 0, '+': 0, '0': 0, '-': 0, '--': 0
    };
    
    correlacoes.forEach(corr => {
        counts[corr.correlacao]++;
    });
    
    // Adiciona correlações neutras não definidas
    counts['0'] += totalCorrelacoes - correlacoesFeitas;
    
    const summaryHTML = `
        <h4>Resumo das Correlações</h4>
        <div class="summary-grid">
            <div class="summary-item strong-positive">
                <div class="summary-icon">++</div>
                <div class="summary-content">
                    <span class="summary-count">${counts['++']}</span>
                    <span class="summary-label">Muito Positivas</span>
                </div>
            </div>
            <div class="summary-item positive">
                <div class="summary-icon">+</div>
                <div class="summary-content">
                    <span class="summary-count">${counts['+']}</span>
                    <span class="summary-label">Positivas</span>
                </div>
            </div>
            <div class="summary-item neutral">
                <div class="summary-icon">0</div>
                <div class="summary-content">
                    <span class="summary-count">${counts['0']}</span>
                    <span class="summary-label">Neutras</span>
                </div>
            </div>
            <div class="summary-item negative">
                <div class="summary-icon">-</div>
                <div class="summary-content">
                    <span class="summary-count">${counts['-']}</span>
                    <span class="summary-label">Negativas</span>
                </div>
            </div>
            <div class="summary-item strong-negative">
                <div class="summary-icon">--</div>
                <div class="summary-content">
                    <span class="summary-count">${counts['--']}</span>
                    <span class="summary-label">Muito Negativas</span>
                </div>
            </div>
        </div>
    `;
    
    summaryContainer.innerHTML = summaryHTML;
}

function generateConflictAnalysis() {
    const conflictContainer = document.getElementById('conflict-analysis');
    if (!conflictContainer) return;
    
    const correlacoes = qfdDB.getCorrelacoesProjeto();
    const conflicts = correlacoes.filter(corr => corr.correlacao === '-' || corr.correlacao === '--');
    
    let conflictHTML = '<h4><i class="fas fa-exclamation-triangle"></i> Análise de Conflitos</h4>';
    
    if (conflicts.length === 0) {
        conflictHTML += `
            <div class="no-conflicts">
                <i class="fas fa-check-circle"></i>
                <p>Nenhum conflito identificado entre os requisitos técnicos.</p>
            </div>
        `;
    } else {
        conflictHTML += '<div class="conflicts-list">';
        conflicts.forEach(conflict => {
            const req1 = requisitos.find(r => r.id === conflict.requisito1);
            const req2 = requisitos.find(r => r.id === conflict.requisito2);
            
            if (req1 && req2) {
                const req1Index = requisitos.indexOf(req1) + 1;
                const req2Index = requisitos.indexOf(req2) + 1;
                
                conflictHTML += `
                    <div class="conflict-item ${conflict.correlacao === '--' ? 'severe' : 'moderate'}">
                        <div class="conflict-header">
                            <span class="conflict-symbol">${conflict.correlacao}</span>
                            <span class="conflict-title">Requisitos ${req1Index} e ${req2Index}</span>
                        </div>
                        <div class="conflict-details">
                            <div class="req-conflict">
                                <strong>Req ${req1Index}:</strong> ${req1.descricao}
                            </div>
                            <div class="req-conflict">
                                <strong>Req ${req2Index}:</strong> ${req2.descricao}
                            </div>
                        </div>
                    </div>
                `;
            }
        });
        conflictHTML += '</div>';
    }
    
    conflictContainer.innerHTML = conflictHTML;
}

function generateSynergyAnalysis() {
    const synergyContainer = document.getElementById('synergy-analysis');
    if (!synergyContainer) return;
    
    const correlacoes = qfdDB.getCorrelacoesProjeto();
    const synergies = correlacoes.filter(corr => corr.correlacao === '+' || corr.correlacao === '++');
    
    let synergyHTML = '<h4><i class="fas fa-handshake"></i> Análise de Sinergias</h4>';
    
    if (synergies.length === 0) {
        synergyHTML += `
            <div class="no-synergies">
                <i class="fas fa-info-circle"></i>
                <p>Nenhuma sinergia identificada entre os requisitos técnicos.</p>
            </div>
        `;
    } else {
        synergyHTML += '<div class="synergies-list">';
        synergies.forEach(synergy => {
            const req1 = requisitos.find(r => r.id === synergy.requisito1);
            const req2 = requisitos.find(r => r.id === synergy.requisito2);
            
            if (req1 && req2) {
                const req1Index = requisitos.indexOf(req1) + 1;
                const req2Index = requisitos.indexOf(req2) + 1;
                
                synergyHTML += `
                    <div class="synergy-item ${synergy.correlacao === '++' ? 'strong' : 'moderate'}">
                        <div class="synergy-header">
                            <span class="synergy-symbol">${synergy.correlacao}</span>
                            <span class="synergy-title">Requisitos ${req1Index} e ${req2Index}</span>
                        </div>
                        <div class="synergy-details">
                            <div class="req-synergy">
                                <strong>Req ${req1Index}:</strong> ${req1.descricao}
                            </div>
                            <div class="req-synergy">
                                <strong>Req ${req2Index}:</strong> ${req2.descricao}
                            </div>
                        </div>
                    </div>
                `;
            }
        });
        synergyHTML += '</div>';
    }
    
    synergyContainer.innerHTML = synergyHTML;
}

// Funções utilitárias
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type = 'info') {
    // Remove toast existente
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Anima entrada
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Remove após 3 segundos
    setTimeout(() => {
        toast.classList.add('hide');
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 300);
    }, 3000);
}

function addModalStyles() {
    if (document.getElementById('correlation-popup-styles')) return;
    
    const styles = document.createElement('style');
    styles.id = 'correlation-popup-styles';
    styles.textContent = `
        .correlation-popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .correlation-popup.show {
            opacity: 1;
            visibility: visible;
        }
        
        .correlation-popup.hide {
            opacity: 0;
            visibility: hidden;
        }
        
        .popup-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        
        .popup-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .popup-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem;
            border-bottom: 1px solid #e9ecef;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 12px 12px 0 0;
        }
        
        .popup-header h3 {
            margin: 0;
            font-size: 1.25rem;
        }
        
        .popup-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background 0.3s ease;
        }
        
        .popup-close:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .popup-body {
            padding: 1.5rem;
        }
        
        .requirements-comparison {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .req-display {
            flex: 1;
            text-align: center;
        }
        
        .req-number {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin: 0 auto 0.5rem;
        }
        
        .req-text {
            font-weight: 500;
            margin-bottom: 0.5rem;
            line-height: 1.4;
        }
        
        .req-meta {
            font-size: 0.875rem;
            color: #666;
        }
        
        .vs-separator {
            background: #dee2e6;
            color: #495057;
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.875rem;
        }
        
        .correlation-question {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .correlation-question h4 {
            color: #495057;
            margin: 0;
        }
        
        .correlation-options {
            display: grid;
            gap: 0.75rem;
        }
        
        .corr-option {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            background: white;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: left;
        }
        
        .corr-option:hover {
            border-color: #667eea;
            background: #f8f9ff;
        }
        
        .corr-option.selected {
            border-color: #667eea;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .corr-symbol {
            font-weight: bold;
            font-size: 1.25rem;
            min-width: 30px;
            text-align: center;
        }
        
        .corr-option .corr-symbol.strong-positive { color: #28a745; }
        .corr-option .corr-symbol.positive { color: #17a2b8; }
        .corr-option .corr-symbol.neutral { color: #6c757d; }
        .corr-option .corr-symbol.negative { color: #fd7e14; }
        .corr-option .corr-symbol.strong-negative { color: #dc3545; }
        
        .corr-option.selected .corr-symbol {
            color: white !important;
        }
        
        .corr-label {
            font-weight: 500;
            font-size: 1rem;
        }
        
        .corr-option small {
            display: block;
            opacity: 0.8;
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
        
        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 10001;
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        }
        
        .toast.show {
            opacity: 1;
            transform: translateX(0);
        }
        
        .toast.hide {
            opacity: 0;
            transform: translateX(100%);
        }
        
        .toast-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 1.5rem;
        }
        
        .toast-success {
            border-left: 4px solid #28a745;
        }
        
        .toast-error {
            border-left: 4px solid #dc3545;
        }
        
        .toast-success .fas {
            color: #28a745;
        }
        
        .toast-error .fas {
            color: #dc3545;
        }
        
        @media (max-width: 768px) {
            .popup-content {
                width: 95%;
                max-height: 90vh;
            }
            
            .requirements-comparison {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .vs-separator {
                transform: rotate(90deg);
                margin: 0.5rem 0;
            }
            
            .correlation-options {
                gap: 0.5rem;
            }
            
            .corr-option {
                padding: 0.75rem;
            }
        }
    `;
    
    document.head.appendChild(styles);
}

