/**
 * JavaScript para Página da Matriz QFD Principal
 * Implementa a Casa da Qualidade completa com pop-ups instantâneos
 */

let requisitosCliente = [];
let requisitosProjeto = [];
let totalRelacoes = 0;
let relacoesFeitas = 0;

document.addEventListener('DOMContentLoaded', function() {
    loadData();
    setupMatrix();
    updateStatus();
    addModalStyles();
});

function loadData() {
    requisitosCliente = qfdDB.getRequisitosCliente();
    requisitosProjeto = qfdDB.getRequisitosProjeto();
    totalRelacoes = requisitosCliente.length * requisitosProjeto.length;
    
    const relacoes = qfdDB.getMatrizQFDCompleta();
    relacoesFeitas = relacoes.length;
}

function setupMatrix() {
    const insufficientDiv = document.getElementById('insufficient-data');
    const qfdSection = document.getElementById('qfd-section');
    const legendSection = document.getElementById('influence-legend');
    const resultsSection = document.getElementById('results-section');
    
    if (requisitosCliente.length === 0 || requisitosProjeto.length === 0) {
        insufficientDiv.style.display = 'block';
        qfdSection.style.display = 'none';
        legendSection.style.display = 'none';
        resultsSection.style.display = 'none';
        return;
    }
    
    insufficientDiv.style.display = 'none';
    qfdSection.style.display = 'block';
    legendSection.style.display = 'block';
    
    generateQFDMatrix();
    
    if (relacoesFeitas > 0) {
        showResults();
    }
}

function generateQFDMatrix() {
    const matrixContainer = document.getElementById('qfd-matrix');
    if (!matrixContainer) return;
    
    let matrixHTML = '<table class="qfd-table">';
    
    // Cabeçalho com telhado (correlações)
    matrixHTML += generateRoofHeader();
    
    // Cabeçalho principal com requisitos de projeto
    matrixHTML += generateMainHeader();
    
    // Linhas da matriz com requisitos de cliente
    matrixHTML += generateMatrixRows();
    
    // Rodapé com cálculos
    matrixHTML += generateMatrixFooter();
    
    matrixHTML += '</table>';
    
    matrixContainer.innerHTML = matrixHTML;
    
    // Adiciona event listeners para as células
    addMatrixEventListeners();
}

function generateRoofHeader() {
    const correlacoes = qfdDB.getCorrelacoesProjeto();
    
    let roofHTML = 
        `<thead class="qfd-roof">
            <tr>
                <th class="corner-cell"></th>
                <th class="corner-cell"></th>
                ${requisitosProjeto.slice(1).map((req, i) => 
                    `<th class="roof-header-cell" title="${escapeHtml(req.descricao)}">
                        <span class="req-number">${i + 2}</span>
                    </th>`
                ).join("")}
                <th class="corner-cell"></th>
            </tr>`;

    for (let i = 0; i < requisitosProjeto.length - 1; i++) {
        roofHTML += `<tr>
            <th class="roof-row-header" title="${escapeHtml(requisitosProjeto[i].descricao)}">
                <span class="req-number">${i + 1}</span>
            </th>
            <th class="roof-spacer"></th>`;
        
        // Células de correlação
        for (let j = i + 1; j < requisitosProjeto.length; j++) {
            const correlation = qfdDB.getCorrelacaoProjeto(requisitosProjeto[i].id, requisitosProjeto[j].id);
            roofHTML += `<th class="roof-cell" title="Correlação entre ${i+1} e ${j+1}">
                ${getCorrelationSymbol(correlation)}
            </th>`;
        }
        
        // Células vazias para completar a linha
        for (let k = 0; k < i; k++) {
            roofHTML += `<th class="roof-empty"></th>`;
        }
        
        roofHTML += `<th class="roof-spacer"></th>`;
        roofHTML += `</tr>`;
    }
    
    roofHTML += `</thead>`;
    return roofHTML;
}

function generateMainHeader() {
    let headerHTML = '<thead class="qfd-header">';
    
    // Linha com números dos requisitos
    headerHTML += '<tr>';
    headerHTML += '<th class="corner-cell">Requisitos</th>';
    
    for (let i = 0; i < requisitosProjeto.length; i++) {
        headerHTML += `<th class="req-number-cell" title="${escapeHtml(requisitosProjeto[i].descricao)}">
            <div class="req-number">${i + 1}</div>
        </th>`;
    }
    
    headerHTML += '<th class="importance-header">Importância Cliente</th>';
    headerHTML += '</tr>';
    
    // Linha com sentidos de melhoria
    headerHTML += '<tr>';
    headerHTML += '<th class="direction-label">Sentido</th>';
    
    for (let i = 0; i < requisitosProjeto.length; i++) {
        const req = requisitosProjeto[i];
        headerHTML += `<th class="direction-cell">
            <div class="direction-symbol ${req.sentidoMelhoria}">
                ${getSentidoSymbol(req.sentidoMelhoria)}
            </div>
        </th>`;
    }
    
    headerHTML += '<th class="importance-cell">Peso (%)</th>';
    headerHTML += '</tr>';
    
    headerHTML += '</thead>';
    return headerHTML;
}

function generateMatrixRows() {
    let rowsHTML = '<tbody class="qfd-body">';
    
    for (let i = 0; i < requisitosCliente.length; i++) {
        const reqCliente = requisitosCliente[i];
        
        rowsHTML += '<tr class="matrix-row">';
        
        // Cabeçalho da linha (requisito de cliente)
        rowsHTML += `<td class="row-header" title="${escapeHtml(reqCliente.descricao)}">
            <div class="req-info">
                <span class="req-number">${i + 1}</span>
                <span class="req-text">${truncateText(reqCliente.descricao, 40)}</span>
            </div>
        </td>`;
        
        // Células de influência
        for (let j = 0; j < requisitosProjeto.length; j++) {
            const reqProjeto = requisitosProjeto[j];
            const influencia = qfdDB.getMatrizQFD(reqCliente.id, reqProjeto.id);
            
            rowsHTML += `<td class="influence-cell ${influencia > 0 ? 'filled' : ''}" 
                onclick="openInfluencePopup('${reqCliente.id}', '${reqProjeto.id}', ${i}, ${j})"
                data-cliente="${reqCliente.id}" 
                data-projeto="${reqProjeto.id}"
                data-i="${i}" 
                data-j="${j}">
                ${influencia > 0 ? `<span class="influence-value level-${influencia}">${influencia}</span>` : ''}
            </td>`;
        }
        
        // Célula de importância do cliente
        rowsHTML += `<td class="client-importance">
            <div class="importance-info">
                <span class="importance-value">${reqCliente.importancia.toFixed(1)}</span>
                <span class="importance-percent">${(reqCliente.peso * 100).toFixed(1)}%</span>
            </div>
        </td>`;
        
        rowsHTML += '</tr>';
    }
    
    rowsHTML += '</tbody>';
    return rowsHTML;
}

function generateMatrixFooter() {
    let footerHTML = '<tfoot class="qfd-footer">';
    
    // Linha de importância absoluta
    footerHTML += '<tr>';
    footerHTML += '<td class="footer-label">Importância Absoluta</td>';
    
    for (let j = 0; j < requisitosProjeto.length; j++) {
        const req = requisitosProjeto[j];
        footerHTML += `<td class="absolute-importance">
            <span class="abs-value">${req.importanciaAbsoluta.toFixed(1)}</span>
        </td>`;
    }
    
    footerHTML += '<td class="footer-spacer"></td>';
    footerHTML += '</tr>';
    
    // Linha de ranking
    footerHTML += '<tr>';
    footerHTML += '<td class="footer-label">Ranking</td>';
    
    for (let j = 0; j < requisitosProjeto.length; j++) {
        const req = requisitosProjeto[j];
        footerHTML += `<td class="ranking-cell">
            <span class="ranking-value ${req.importanciaRelativa <= 3 ? 'top-rank' : ''}">${req.importanciaRelativa}º</span>
        </td>`;
    }
    
    footerHTML += '<td class="footer-spacer"></td>';
    footerHTML += '</tr>';
    
    // Linha de peso relativo
    footerHTML += '<tr>';
    footerHTML += '<td class="footer-label">Peso Relativo (%)</td>';
    
    for (let j = 0; j < requisitosProjeto.length; j++) {
        const req = requisitosProjeto[j];
        footerHTML += `<td class="relative-weight">
            <span class="weight-value">${(req.pesoRelativo * 100).toFixed(1)}%</span>
        </td>`;
    }
    
    footerHTML += '<td class="footer-spacer"></td>';
    footerHTML += '</tr>';
    
    // Linha de dificuldade técnica
    footerHTML += '<tr>';
    footerHTML += '<td class="footer-label">Dificuldade Técnica</td>';
    
    for (let j = 0; j < requisitosProjeto.length; j++) {
        const req = requisitosProjeto[j];
        footerHTML += `<td class="technical-difficulty">
            <span class="difficulty-value level-${req.dificuldadeTecnica}">${req.dificuldadeTecnica}</span>
        </td>`;
    }
    
    footerHTML += '<td class="footer-spacer"></td>';
    footerHTML += '</tr>';
    
    footerHTML += '</tfoot>';
    return footerHTML;
}

function addMatrixEventListeners() {
    // Event listeners já são adicionados via onclick no HTML
}

function openInfluencePopup(clienteId, projetoId, i, j) {
    const reqCliente = requisitosCliente[i];
    const reqProjeto = requisitosProjeto[j];
    const currentInfluence = qfdDB.getMatrizQFD(clienteId, projetoId);
    
    // Remove qualquer modal existente
    const existingModal = document.querySelector('.influence-popup');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Cria popup
    const popup = document.createElement('div');
    popup.className = 'influence-popup';
    popup.innerHTML = `
        <div class="popup-overlay" onclick="closeInfluencePopup()"></div>
        <div class="popup-content">
            <div class="popup-header">
                <h3>Definir Influência</h3>
                <button class="popup-close" onclick="closeInfluencePopup()">&times;</button>
            </div>
            <div class="popup-body">
                <div class="influence-question">
                    <h4>Qual a influência do requisito técnico no atendimento da necessidade do cliente?</h4>
                </div>
                
                <div class="requirements-comparison">
                    <div class="req-display client">
                        <div class="req-header">
                            <i class="fas fa-user"></i>
                            <span class="req-label">Cliente ${i + 1}</span>
                        </div>
                        <div class="req-text">${escapeHtml(reqCliente.descricao)}</div>
                        <div class="req-meta">
                            <span class="importance-badge">
                                <i class="fas fa-star"></i> Importância: ${reqCliente.importancia.toFixed(1)}
                            </span>
                        </div>
                    </div>
                    
                    <div class="influence-arrow">
                        <i class="fas fa-arrow-down"></i>
                        <span>influencia</span>
                    </div>
                    
                    <div class="req-display project">
                        <div class="req-header">
                            <i class="fas fa-cog"></i>
                            <span class="req-label">Projeto ${j + 1}</span>
                        </div>
                        <div class="req-text">${escapeHtml(reqProjeto.descricao)}</div>
                        <div class="req-meta">
                            <span class="direction-badge ${reqProjeto.sentidoMelhoria}">
                                ${getSentidoSymbol(reqProjeto.sentidoMelhoria)} ${getSentidoLabel(reqProjeto.sentidoMelhoria)}
                            </span>
                            <span class="difficulty-badge level-${reqProjeto.dificuldadeTecnica}">
                                Dif: ${reqProjeto.dificuldadeTecnica}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div class="influence-options">
                    <button class="influence-option ${currentInfluence === 0 ? 'selected' : ''}" 
                            onclick="selectInfluence(0, '${clienteId}', '${projetoId}')">
                        <span class="influence-symbol">∅</span>
                        <span class="influence-label">Sem Influência</span>
                        <small>Não há relação significativa</small>
                    </button>
                    <button class="influence-option ${currentInfluence === 1 ? 'selected' : ''}" 
                            onclick="selectInfluence(1, '${clienteId}', '${projetoId}')">
                        <span class="influence-symbol level-1">1</span>
                        <span class="influence-label">Influência Fraca</span>
                        <small>Pouco impacto no atendimento</small>
                    </button>
                    <button class="influence-option ${currentInfluence === 3 ? 'selected' : ''}" 
                            onclick="selectInfluence(3, '${clienteId}', '${projetoId}')">
                        <span class="influence-symbol level-3">3</span>
                        <span class="influence-label">Influência Moderada</span>
                        <small>Impacto moderado no atendimento</small>
                    </button>
                    <button class="influence-option ${currentInfluence === 5 ? 'selected' : ''}" 
                            onclick="selectInfluence(5, '${clienteId}', '${projetoId}')">
                        <span class="influence-symbol level-5">5</span>
                        <span class="influence-label">Influência Forte</span>
                        <small>Grande impacto no atendimento</small>
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(popup);
    
    // Anima a entrada
    setTimeout(() => {
        popup.classList.add('show');
    }, 10);
}

function selectInfluence(influence, clienteId, projetoId) {
    try {
        // Salva imediatamente
        qfdDB.setMatrizQFD(clienteId, projetoId, influence);
        
        // Atualiza interface
        loadData();
        generateQFDMatrix();
        updateStatus();
        showResults();
        
        // Fecha popup
        closeInfluencePopup();
        
        // Mostra feedback
        showToast('Influência salva com sucesso!', 'success');
        
    } catch (error) {
        console.error('Erro ao salvar influência:', error);
        showToast('Erro ao salvar influência', 'error');
    }
}

function closeInfluencePopup() {
    const popup = document.querySelector('.influence-popup');
    if (popup) {
        popup.classList.add('hide');
        setTimeout(() => {
            popup.remove();
        }, 300);
    }
}

function updateStatus() {
    const totalClienteElement = document.getElementById('total-req-cliente');
    const totalProjetoElement = document.getElementById('total-req-projeto');
    const relacoesElement = document.getElementById('relacoes-feitas');
    const progressoElement = document.getElementById('progresso-percentual');
    const progressFill = document.getElementById('progress-fill');
    
    if (totalClienteElement) {
        totalClienteElement.textContent = requisitosCliente.length;
    }
    
    if (totalProjetoElement) {
        totalProjetoElement.textContent = requisitosProjeto.length;
    }
    
    if (relacoesElement) {
        relacoesElement.textContent = `${relacoesFeitas} / ${totalRelacoes}`;
    }
    
    const progresso = totalRelacoes > 0 ? Math.round((relacoesFeitas / totalRelacoes) * 100) : 0;
    
    if (progressoElement) {
        progressoElement.textContent = `${progresso}%`;
    }
    
    if (progressFill) {
        progressFill.style.width = `${progresso}%`;
    }
}

function showResults() {
    const resultsSection = document.getElementById('results-section');
    if (!resultsSection) return;
    
    resultsSection.style.display = 'block';
    
    generateRanking();
    generateMetrics();
    generateAnalysis();
}

function generateRanking() {
    const rankingContainer = document.getElementById('ranking-container');
    if (!rankingContainer) return;
    
    // Ordena requisitos por importância absoluta
    const sortedRequisitos = [...requisitosProjeto].sort((a, b) => b.importanciaAbsoluta - a.importanciaAbsoluta);
    
    let rankingHTML = '<h4>Ranking dos Requisitos de Projeto</h4>';
    rankingHTML += '<div class="ranking-list">';
    
    sortedRequisitos.forEach((req, index) => {
        const originalIndex = requisitosProjeto.indexOf(req);
        rankingHTML += `
            <div class="ranking-item ${index < 3 ? 'top-rank' : ''}">
                <div class="rank-position">${index + 1}º</div>
                <div class="rank-content">
                    <div class="rank-header">
                        <span class="req-number">Req ${originalIndex + 1}</span>
                        <span class="importance-score">${req.importanciaAbsoluta.toFixed(1)}</span>
                    </div>
                    <div class="req-description">${req.descricao}</div>
                    <div class="req-details">
                        <span class="weight-badge">${(req.pesoRelativo * 100).toFixed(1)}%</span>
                        <span class="difficulty-badge level-${req.dificuldadeTecnica}">Dif: ${req.dificuldadeTecnica}</span>
                        <span class="direction-badge ${req.sentidoMelhoria}">
                            ${getSentidoSymbol(req.sentidoMelhoria)} ${getSentidoLabel(req.sentidoMelhoria)}
                        </span>
                    </div>
                </div>
            </div>
        `;
    });
    
    rankingHTML += '</div>';
    rankingContainer.innerHTML = rankingHTML;
}

function generateMetrics() {
    const metricsContainer = document.getElementById('metrics-container');
    if (!metricsContainer) return;
    
    // Calcula métricas
    const totalImportancia = requisitosProjeto.reduce((sum, req) => sum + req.importanciaAbsoluta, 0);
    const mediaImportancia = totalImportancia / requisitosProjeto.length;
    const maxImportancia = Math.max(...requisitosProjeto.map(req => req.importanciaAbsoluta));
    const minImportancia = Math.min(...requisitosProjeto.map(req => req.importanciaAbsoluta));
    
    const metricsHTML = `
        <h4>Métricas da Matriz QFD</h4>
        <div class="metrics-grid">
            <div class="metric-item">
                <div class="metric-value">${totalRelacoes}</div>
                <div class="metric-label">Total de Relações</div>
            </div>
            <div class="metric-item">
                <div class="metric-value">${relacoesFeitas}</div>
                <div class="metric-label">Relações Definidas</div>
            </div>
            <div class="metric-item">
                <div class="metric-value">${Math.round((relacoesFeitas / totalRelacoes) * 100)}%</div>
                <div class="metric-label">Completude</div>
            </div>
            <div class="metric-item">
                <div class="metric-value">${mediaImportancia.toFixed(1)}</div>
                <div class="metric-label">Importância Média</div>
            </div>
            <div class="metric-item">
                <div class="metric-value">${maxImportancia.toFixed(1)}</div>
                <div class="metric-label">Maior Importância</div>
            </div>
            <div class="metric-item">
                <div class="metric-value">${minImportancia.toFixed(1)}</div>
                <div class="metric-label">Menor Importância</div>
            </div>
        </div>
    `;
    
    metricsContainer.innerHTML = metricsHTML;
}

function generateAnalysis() {
    const analysisContainer = document.getElementById('analysis-container');
    if (!analysisContainer) return;
    
    // Análise dos requisitos mais críticos
    const topRequisitos = [...requisitosProjeto]
        .sort((a, b) => b.importanciaAbsoluta - a.importanciaAbsoluta)
        .slice(0, 3);
    
    let analysisHTML = '<h4>Análise dos Resultados</h4>';
    
    if (topRequisitos.length > 0) {
        analysisHTML += '<div class="analysis-section">';
        analysisHTML += '<h5>Requisitos Mais Críticos</h5>';
        analysisHTML += '<p>Os requisitos de projeto com maior impacto no atendimento das necessidades dos clientes são:</p>';
        analysisHTML += '<ul>';
        
        topRequisitos.forEach((req, index) => {
            const originalIndex = requisitosProjeto.indexOf(req);
            analysisHTML += `<li><strong>Req ${originalIndex + 1}:</strong> ${req.descricao} (Importância: ${req.importanciaAbsoluta.toFixed(1)})</li>`;
        });
        
        analysisHTML += '</ul>';
        analysisHTML += '</div>';
    }
    
    // Análise de distribuição
    const distribuicao = {
        alta: requisitosProjeto.filter(req => req.pesoRelativo > 0.15).length,
        media: requisitosProjeto.filter(req => req.pesoRelativo >= 0.05 && req.pesoRelativo <= 0.15).length,
        baixa: requisitosProjeto.filter(req => req.pesoRelativo < 0.05).length
    };
    
    analysisHTML += '<div class="analysis-section">';
    analysisHTML += '<h5>Distribuição de Importância</h5>';
    analysisHTML += `
        <div class="distribution-chart">
            <div class="dist-item alta">
                <span class="dist-count">${distribuicao.alta}</span>
                <span class="dist-label">Alta Importância (>15%)</span>
            </div>
            <div class="dist-item media">
                <span class="dist-count">${distribuicao.media}</span>
                <span class="dist-label">Média Importância (5-15%)</span>
            </div>
            <div class="dist-item baixa">
                <span class="dist-count">${distribuicao.baixa}</span>
                <span class="dist-label">Baixa Importância (<5%)</span>
            </div>
        </div>
    `;
    analysisHTML += '</div>';
    
    analysisContainer.innerHTML = analysisHTML;
}

// Funções utilitárias
function getCorrelationSymbol(correlation) {
    const symbols = {
        '++': '<span class="corr-symbol strong-positive">++</span>',
        '+': '<span class="corr-symbol positive">+</span>',
        '0': '<span class="corr-symbol neutral">0</span>',
        '-': '<span class="corr-symbol negative">-</span>',
        '--': '<span class="corr-symbol strong-negative">--</span>'
    };
    return symbols[correlation] || '';
}

function getSentidoSymbol(sentido) {
    const symbols = { 'up': '↑', 'down': '↓', 'none': '*' };
    return symbols[sentido] || '?';
}

function getSentidoLabel(sentido) {
    const labels = { 'up': 'Crescente', 'down': 'Decrescente', 'none': 'Nominal' };
    return labels[sentido] || 'Indefinido';
}

function truncateText(text, maxLength) {
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type = 'info') {
    // Remove toast existente
    const existingToast = document.querySelector('.toast');
    if (existingToast) {
        existingToast.remove();
    }
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // Anima entrada
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Remove após 3 segundos
    setTimeout(() => {
        toast.classList.add('hide');
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 300);
    }, 3000);
}

function addModalStyles() {
    if (document.getElementById('influence-popup-styles')) return;
    
    const styles = document.createElement('style');
    styles.id = 'influence-popup-styles';
    styles.textContent = `
        .influence-popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .influence-popup.show {
            opacity: 1;
            visibility: visible;
        }
        
        .influence-popup.hide {
            opacity: 0;
            visibility: hidden;
        }
        
        .popup-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
        }
        
        .popup-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }
        
        .popup-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.5rem;
            border-bottom: 1px solid #e9ecef;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 12px 12px 0 0;
        }
        
        .popup-header h3 {
            margin: 0;
            font-size: 1.25rem;
        }
        
        .popup-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background 0.3s ease;
        }
        
        .popup-close:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .popup-body {
            padding: 1.5rem;
        }
        
        .influence-question {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .influence-question h4 {
            color: #495057;
            margin: 0;
        }
        
        .requirements-comparison {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 8px;
        }
        
        .req-display {
            flex: 1;
            text-align: center;
        }
        
        .req-display.client {
            border-left: 4px solid #007bff;
            padding-left: 1rem;
        }
        
        .req-display.project {
            border-left: 4px solid #28a745;
            padding-left: 1rem;
        }
        
        .req-header {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #495057;
        }
        
        .req-text {
            font-weight: 500;
            margin-bottom: 0.5rem;
            line-height: 1.4;
        }
        
        .req-meta {
            font-size: 0.875rem;
            color: #666;
        }
        
        .influence-arrow {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.25rem;
            background: #dee2e6;
            color: #495057;
            padding: 0.5rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: bold;
        }
        
        .influence-options {
            display: grid;
            gap: 0.75rem;
        }
        
        .influence-option {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            background: white;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: left;
        }
        
        .influence-option:hover {
            border-color: #667eea;
            background: #f8f9ff;
        }
        
        .influence-option.selected {
            border-color: #667eea;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .influence-symbol {
            font-weight: bold;
            font-size: 1.25rem;
            min-width: 30px;
            text-align: center;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
        }
        
        .influence-option .influence-symbol.level-1 { 
            background: #ffc107; 
            color: #212529;
        }
        .influence-option .influence-symbol.level-3 { 
            background: #17a2b8; 
            color: white;
        }
        .influence-option .influence-symbol.level-5 { 
            background: #28a745; 
            color: white;
        }
        
        .influence-option.selected .influence-symbol {
            background: rgba(255, 255, 255, 0.2) !important;
            color: white !important;
        }
        
        .influence-label {
            font-weight: 500;
            font-size: 1rem;
        }
        
        .influence-option small {
            display: block;
            opacity: 0.8;
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
        
        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 10001;
            opacity: 0;
            transform: translateX(100%);
            transition: all 0.3s ease;
        }
        
        .toast.show {
            opacity: 1;
            transform: translateX(0);
        }
        
        .toast.hide {
            opacity: 0;
            transform: translateX(100%);
        }
        
        .toast-content {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 1.5rem;
        }
        
        .toast-success {
            border-left: 4px solid #28a745;
        }
        
        .toast-error {
            border-left: 4px solid #dc3545;
        }
        
        .toast-success .fas {
            color: #28a745;
        }
        
        .toast-error .fas {
            color: #dc3545;
        }
        
        @media (max-width: 768px) {
            .popup-content {
                width: 95%;
                max-height: 90vh;
            }
            
            .requirements-comparison {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .influence-arrow {
                transform: rotate(90deg);
                margin: 0.5rem 0;
            }
            
            .influence-options {
                gap: 0.5rem;
            }
            
            .influence-option {
                padding: 0.75rem;
            }
        }
    `;
    
    document.head.appendChild(styles);
}

