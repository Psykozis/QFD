# Relatório de Análise do Sistema QFD - Compartilhamento de Dados

## Introdução

Este relatório detalha a análise do sistema QFD fornecido, com foco na persistência e compartilhamento de dados entre as páginas. O objetivo é identificar o motivo pelo qual os dados podem não estar sendo compartilhados conforme o esperado.

## Arquitetura de Dados

O sistema QFD utiliza o `localStorage` do navegador para armazenar e persistir os dados. A classe `QFDDatabase` (definida em `js/database.js`) é responsável por gerenciar todas as operações de CRUD (Criar, Ler, Atualizar, Deletar) para os diferentes tipos de dados do sistema (requisitos de cliente, requisitos de projeto, comparações, correlações e matriz QFD).

Cada página HTML (por exemplo, `index.html`, `pages/requisitos-cliente.html`) inclui o script `js/database.js`, o que significa que todas as páginas acessam a mesma instância global de `QFDDatabase` e, consequentemente, o mesmo `localStorage`.

## Potenciais Motivos para Falha no Compartilhamento de Dados

Embora o `localStorage` seja projetado para compartilhar dados entre páginas da mesma origem, existem alguns cenários comuns que podem impedir esse comportamento:

### 1. Problemas de Origem (Origin Issues)

O `localStorage` é restrito à origem (protocolo, domínio e porta). Se as páginas do sistema QFD estiverem sendo acessadas de origens diferentes, o `localStorage` não será compartilhado. Exemplos de situações que podem causar isso:

*   **Acesso via `file://` e `http://`:** Abrir arquivos HTML diretamente do sistema de arquivos (`file://`) e, em seguida, tentar acessá-los via um servidor web local (`http://localhost`) fará com que o navegador trate as duas como origens diferentes.
*   **Domínios/Portas Diferentes:** Se o sistema for implantado em diferentes subdomínios ou portas (ex: `http://localhost:8000` e `http://localhost:3000`), o `localStorage` não será compartilhado entre eles.

**Solução:** Certifique-se de que todas as páginas do sistema QFD sejam acessadas da mesma origem. A maneira mais robusta de fazer isso é sempre servir os arquivos através de um servidor web (por exemplo, Apache, Nginx, ou um servidor Python simples como `python -m http.server`).

### 2. Erros de JavaScript

Erros no código JavaScript podem impedir que os dados sejam salvos ou carregados corretamente do `localStorage`. Isso pode incluir:

*   **Erros de Sintaxe ou Lógica:** Bugs que impedem a execução das funções `saveData()` ou `loadData()`.
*   **Exceções:** Erros em tempo de execução que não são tratados e interrompem o fluxo de salvamento/carregamento.

**Solução:** Verifique o console do navegador (geralmente acessível via F12) em busca de mensagens de erro ou avisos. Eles podem indicar problemas na execução do JavaScript que afetam a persistência dos dados.

### 3. Limpeza Acidental de Dados

O usuário pode estar, sem querer, limpando os dados do `localStorage`. Isso pode acontecer de algumas formas:

*   **Função `resetAllData()`:** O sistema possui um botão 


que chama a função `resetAllData()`, que apaga todos os dados do `localStorage` relacionados ao sistema QFD. Se o usuário clicar neste botão, os dados serão perdidos.
*   **Limpeza do Cache do Navegador:** A limpeza do cache, cookies e dados do site nas configurações do navegador também removerá os dados do `localStorage`.

**Solução:** Educar o usuário sobre a função `resetAllData()` e seus efeitos. Evitar limpar o cache do navegador, a menos que seja intencional.

### 4. Conflitos de Chave (Menos Provável)

Embora improvável para este sistema, se houver outras aplicações web sendo executadas na mesma origem e utilizando a mesma chave de `localStorage` (`qfd_data`), pode haver sobrescrita ou leitura de dados incorretos.

**Solução:** Garantir que as chaves de `localStorage` sejam únicas para cada aplicação. No caso do sistema QFD, a chave `qfd_data` parece ser específica e bem definida.

## Conclusão e Recomendações

Com base na análise do código, o mecanismo de persistência de dados via `localStorage` está implementado corretamente para permitir o compartilhamento entre páginas da mesma origem. A causa mais provável para a falta de compartilhamento de dados é um problema de **origem** (como os arquivos estão sendo acessados) ou a ocorrência de **erros de JavaScript** que impedem o salvamento/carregamento.

**Recomendações para o Usuário:**

1.  **Verifique a Origem:** Sempre acesse o sistema QFD através de um servidor web local (ex: `http://localhost:8000/index.html`) para garantir que todas as páginas estejam na mesma origem. Evite abrir os arquivos HTML diretamente do explorador de arquivos (`file://`).
2.  **Inspecione o Console do Navegador:** Abra as ferramentas de desenvolvedor do seu navegador (F12) e verifique a aba "Console" em busca de quaisquer mensagens de erro ou avisos ao navegar entre as páginas e interagir com o sistema. Erros podem indicar falhas no salvamento ou carregamento dos dados.
3.  **Teste a Função `resetAllData()` com Cuidado:** Esteja ciente de que o botão "Limpar Todos os Dados" apaga permanentemente todas as informações do projeto.

Ao seguir estas recomendações, será possível identificar a causa raiz do problema de compartilhamento de dados e garantir o funcionamento adequado do sistema QFD.



## Análise e Correção do Problema de Salvamento nas Páginas de Correlação e Matriz QFD

### Problema Identificado

Foi reportado que, nas páginas de Correlação de Projeto (`pages/correlacao-projeto.html`) e Matriz QFD (`pages/matriz-qfd.html`), não era possível salvar informações após a primeira entrada, ou que as alterações não eram persistidas corretamente.

Após análise dos arquivos JavaScript `js/correlacao-projeto.js` e `js/matriz-qfd.js`, identificou-se que o problema estava relacionado à forma como o valor selecionado (correlação ou influência) era armazenado e acessado antes de ser salvo no `localStorage`.

Especificamente:

*   **`correlacao-projeto.js`:** A variável `selectedCorrelation` dentro da função `setupModalEventListeners` era atualizada corretamente quando um botão de correlação era clicado. No entanto, o objeto global `window.currentCorrelationData`, que é usado pela função `saveCorrelation()` para obter os dados a serem salvos, não estava sendo atualizado com o `selectedCorrelation` mais recente após uma nova seleção. Ele era inicializado com o `currentCorrelation` (valor inicial) e não era modificado posteriormente.
*   **`matriz-qfd.js`:** O mesmo problema ocorria na função `setupInfluenceModalEventListeners` com a variável `selectedInfluence` e o objeto global `window.currentInfluenceData`.

Isso resultava em `saveCorrelation()` e `saveInfluence()` sempre tentando salvar o valor inicial da correlação/influência (ou o valor da primeira seleção), em vez do valor mais recentemente escolhido pelo usuário no modal.

### Solução Implementada

A correção envolveu garantir que o valor selecionado dentro do modal seja imediatamente refletido no objeto global que será usado para salvar os dados. As seguintes alterações foram aplicadas:

*   **`js/correlacao-projeto.js`:**
    *   Dentro do `eventListener` para os botões de correlação, após `selectedCorrelation = btn.dataset.value;`, foi adicionada uma linha para atualizar o objeto global: `window.currentCorrelationData.selectedCorrelation = selectedCorrelation;`.
    *   Foi ajustada a lógica de habilitação do botão 


de salvar para que ele seja habilitado tanto na seleção inicial quanto em seleções subsequentes.

*   **`js/matriz-qfd.js`:**
    *   Similarmente, dentro do `eventListener` para os botões de influência, após `selectedInfluence = parseInt(btn.dataset.value);`, foi adicionada a linha: `window.currentInfluenceData.selectedInfluence = selectedInfluence;`.
    *   A lógica de habilitação do botão de salvar também foi ajustada para refletir a seleção atual.

Com essas modificações, o valor selecionado no modal é corretamente passado para a função de salvamento, garantindo que as informações sejam persistidas no `localStorage` conforme a interação do usuário.

### Recomendações Adicionais

*   **Teste Abrangente:** Recomenda-se testar exaustivamente as páginas de Correlação e Matriz QFD após a aplicação das correções, inserindo e modificando dados para garantir que o salvamento esteja funcionando conforme o esperado.
*   **Monitoramento do Console:** Continue monitorando o console do navegador para quaisquer novos erros ou avisos que possam surgir, pois eles são cruciais para depuração.

Estas correções devem resolver o problema de não salvamento nas páginas específicas, permitindo que o usuário utilize o sistema QFD em sua totalidade.

