# Sistema QFD - Quality Function Deployment

Este repositório contém o código-fonte de um sistema interativo de Quality Function Deployment (QFD), desenvolvido para auxiliar engenheiros de produto na tradução das necessidades dos clientes em características técnicas de projeto.

## Sobre o Projeto

Este sistema foi gerado através da inteligência artificial Manus AI, com prompt gerado pelo engenheiro em eletrônica Marlon Soares Sigales. O objetivo é fornecer uma ferramenta prática e funcional para a aplicação da metodologia QFD. Os códigos estão abertos para quem quiser contribuir ou modificar.

## Funcionalidades

*   **Dashboard:** Visão geral do progresso do projeto QFD.
*   **Requisitos de Cliente:** Gerenciamento e priorização das necessidades do cliente.
*   **Comparação Cliente:** Hierarquização da importância dos requisitos do cliente.
*   **Requisitos de Projeto:** Definição das características técnicas do produto.
*   **Correlação Projeto:** Análise das relações entre os requisitos técnicos (telhado do QFD).
*   **Matriz QFD:** Relacionamento entre requisitos de cliente e projeto (Casa da Qualidade).
*   **Relatório PDF:** Geração de relatório técnico padronizado com a matriz QFD.
*   **Persistência de Dados:** Todos os dados são salvos localmente no navegador (localStorage).

## Acessar o Site

Você pode acessar a versão mais recente do sistema QFD online através do seguinte link:

[Acessar Sistema QFD](https://QualityFunctionDeployment-NIMEq-UFPel.manus.space) (Domínio a ser atualizado)

## Como Usar (Passo a Passo)

### 1. Requisitos de Cliente

*   Navegue até a aba "Requisitos Cliente".
*   Clique em "Adicionar Requisito" para inserir as necessidades do cliente.
*   Preencha a descrição e a importância (1 a 5).
*   Clique em "Salvar" para adicionar o requisito.

### 2. Comparação Cliente

*   Após adicionar os requisitos de cliente, vá para a aba "Comparação Cliente".
*   Você verá uma matriz para comparar cada par de requisitos.
*   Clique nas células da matriz para indicar a importância relativa entre os requisitos (ex: 1 para igual, 3 para moderadamente mais importante, 5 para muito mais importante).
*   Os valores são salvos automaticamente.

### 3. Requisitos de Projeto

*   Vá para a aba "Requisitos Projeto".
*   Adicione as características técnicas ou de engenharia que o produto deve ter.
*   Preencha a descrição, o sentido de melhoria (para cima, para baixo, nenhum) e a dificuldade técnica (1 a 3).
*   Clique em "Salvar".

### 4. Correlação Projeto (Telhado do QFD)

*   Acesse a aba "Correlação Projeto".
*   Esta seção representa o "telhado" do QFD, mostrando as interações entre os requisitos de projeto.
*   Clique nas células da matriz triangular para definir a correlação entre os requisitos de projeto (ex: ++ para forte positiva, -- para forte negativa).
*   Um pop-up aparecerá para facilitar a seleção e o salvamento.

### 5. Matriz QFD (Casa da Qualidade)

*   Navegue até a aba "Matriz QFD".
*   Esta é a parte central da Casa da Qualidade, onde os requisitos de cliente são relacionados com os requisitos de projeto.
*   Clique nas células da matriz para indicar a força da relação entre um requisito de cliente e um requisito de projeto (ex: 0 para nenhuma, 1 para fraca, 3 para média, 5 para forte).
*   Um pop-up auxiliará na seleção e salvamento.
*   As métricas de importância absoluta, ranking, peso relativo e dificuldade técnica serão calculadas automaticamente no rodapé da matriz.

### 6. Relatório PDF

*   Vá para a aba "Relatório PDF".
*   Clique no botão para gerar o relatório técnico completo do QFD, que incluirá todas as informações inseridas e as análises.
*   O relatório será baixado em formato PDF.

### 7. Limpar Dados

*   Na página "Dashboard", você encontrará um botão "Limpar Todos os Dados".
*   Use-o com cautela, pois ele removerá todos os dados salvos no seu navegador.

## Como Usar (Localmente - Para Desenvolvedores)

Para executar o sistema localmente, siga os passos abaixo:

1.  **Clone o repositório:**
    ```bash
    git clone https://github.com/Psykozis/QFD.git
    ```
2.  **Navegue até o diretório do projeto:**
    ```bash
    cd QFD
    ```
3.  **Abra o arquivo `index.html` no seu navegador:**
    Você pode simplesmente arrastar e soltar o arquivo `index.html` para a janela do seu navegador, ou usar um servidor web local (como o Python `http.server`):
    ```bash
    python3 -m http.server 8000
    ```
    Em seguida, acesse `http://localhost:8000` no seu navegador.

## Estrutura do Projeto

```
QFD/
├── css/
│   └── style.css
├── js/
│   ├── database.js
│   ├── dashboard.js
│   ├── correlacao-projeto.js
│   ├── matriz-qfd.js
│   └── ... (outros arquivos JS)
├── pages/
│   ├── index.html
│   ├── requisitos-cliente.html
│   ├── comparacao-cliente.html
│   ├── requisitos-projeto.html
│   ├── correlacao-projeto.html
│   ├── matriz-qfd.html
│   ├── relatorio.html
│   └── ... (outras páginas HTML)
├── generate_qfd_report.py
└── README.md
```

## Contribuição

Sinta-se à vontade para explorar o código, sugerir melhorias ou reportar problemas. Este projeto é um exemplo de como a inteligência artificial pode ser utilizada para criar ferramentas úteis e funcionais.

